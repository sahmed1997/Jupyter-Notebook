# scriptD.py

a = 5
b = 10
c = 7
d = 16
print((a * d) / (b / c)
print('goodbye')
