# scriptA.py

a = 5
b = 10
c = 20
b = 0
d = a / b
print(d)
