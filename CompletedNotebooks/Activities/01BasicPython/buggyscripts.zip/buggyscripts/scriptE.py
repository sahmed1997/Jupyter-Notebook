# scriptE.py

strng = "apples"
print(string, string, string)
